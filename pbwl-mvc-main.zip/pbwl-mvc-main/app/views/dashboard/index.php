<header>
    <img src="layouts/assets/img/hider.jpg" alt="" width="1200" height="100">
</header>
<h2>Dashboard</h2>

<div class="info">Selamat datang, <strong>Silvi Indryani</strong></div>